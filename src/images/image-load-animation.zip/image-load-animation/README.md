# Image Load Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/AnaisKa/pen/RwwdvXG](https://codepen.io/AnaisKa/pen/RwwdvXG).

